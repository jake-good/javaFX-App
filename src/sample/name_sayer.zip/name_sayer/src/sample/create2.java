package sample;

import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.Window;

public class create2 {

    public Button finish;

    public void finish() {
        Stage stage = (Stage)finish.getScene().getWindow();
        stage.close();
        new sceneChange("menu");
    }
}
