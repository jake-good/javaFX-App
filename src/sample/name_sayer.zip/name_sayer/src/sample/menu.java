package sample;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class menu {
    public Button createButton;
    public Button viewButton;

    public void create() {
        new sceneChange("create1");
    }

    public void view() {
        new sceneChange("list");
    }
}
