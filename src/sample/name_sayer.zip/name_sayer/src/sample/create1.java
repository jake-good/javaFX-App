package sample;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class create1 {

    public TextField nameText;
    public Button createNameButton;
    public Button returnButton;

    public void Create() {
        new sceneChange("create2", new Stage());
    }

    public void returnMenu() {
        new sceneChange("menu");
    }

}
