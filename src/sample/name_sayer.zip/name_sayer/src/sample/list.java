package sample;

import javafx.scene.control.Button;

public class list {

    public Button returnButton;

    public void returnMenu() {
        new sceneChange("menu");
    }

}